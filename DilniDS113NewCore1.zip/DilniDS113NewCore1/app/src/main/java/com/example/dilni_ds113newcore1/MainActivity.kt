package com.example.dilni_ds113newcore1

import android.graphics.Color
import android.media.MediaPlayer
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    var output:Int = 0


    override fun onStart() {
        super.onStart()
        Log.i("lifecycle","onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.i("lifecycle", "onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.i("lifecycle","onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.i("lifecycle","onStop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i("lifecycle","onDestroy")
    }

    override fun onRestart() {
        super.onRestart()
        Log.i("lifecycle","onRestart")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.i("lifecycle","onCreate")

        val score = findViewById<Button>(R.id.score)
        val steal = findViewById<Button>(R.id.steal)
        val reset = findViewById<Button>(R.id.reset)
        val result = findViewById<TextView>(R.id.result)
        fun playmusic() {
            if (output == 15)
            {
                result.setTextColor(Color.rgb(170,255,0))
                val audio: MediaPlayer? = MediaPlayer.create(this,R.raw.beep_short)
                audio?.start()
            }
            else
            {
                result.setTextColor(Color.rgb(0,0,0))
            }

        }

        savedInstanceState?.let {
            output = savedInstanceState.getInt("result")
            result.text = output.toString()
        }

        score.setOnClickListener {
            output++
            output = if(output > 15) 15 else output
            result.text = output.toString()
            playmusic()
        }

        steal.setOnClickListener {
            output--
            output = if (output < 0) 0 else output
            result.setTextColor(Color.rgb(0,0,0))
            result.text = output.toString()
        }

        reset.setOnClickListener {
            output = 0
            result.setTextColor(Color.rgb(0,0,0))

            result.text  = output.toString()
        }

    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("result",output)
        Log.i("lifecycle", "saveInstanceState $output")
    }

}