package com.example.ds311_dilnicore2

import android.app.Activity
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.Espresso.pressBack
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.action.ViewActions.replaceText
import androidx.test.espresso.assertion.ViewAssertions
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.espresso.matcher.ViewMatchers.withText
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest

import org.junit.Test
import org.junit.runner.RunWith

import org.junit.Assert.*
import org.junit.Rule
import java.util.regex.Pattern.matches

@LargeTest
@RunWith(AndroidJUnit4::class)
class Core2test {
  @Rule
  @JvmField
  var mainActivityrule =  ActivityScenarioRule(MainActivity::class.java)
    @Test
    fun clickImageShibuya(){
        val Ishibuya = onView(withId(R.id.imgshibuya))
        Ishibuya.perform(click())
    }
    @Test
    fun clickImageLouve(){
        val Ilouve = onView(withId(R.id.imglourve))
        Ilouve.perform(click())
    }
    @Test
    fun clickImageFlinder(){
        val Iflinders = onView(withId(R.id.imgflinderstreet))
         Iflinders.perform(click())
    }
    @Test
    fun clickImageCaptown(){
        val Icaptown = onView(withId(R.id.imgcaptown))
        Icaptown.perform(click())
    }
    @Test
    fun editshibuya(){
        val Ishibuya = onView(withId(R.id.imgshibuya))
        Ishibuya.perform(click())
        val textshibuya = onView(withId(R.id.title))
        textshibuya.perform(replaceText("newcity1"))
        pressBack()
        val checkshibuya = onView(withId(R.id.tshibuya))
        checkshibuya.check(ViewAssertions.matches(withText("newcity1")))
    }
    @Test
    fun editlouve(){
        val Ilouve = onView(withId(R.id.imglourve))
        Ilouve.perform(click())
        val textlouve = onView(withId(R.id.title))
        textlouve.perform(replaceText("newcity2"))
        pressBack()
        val checklouve = onView(withId(R.id.tlourve))
        checklouve.check(ViewAssertions.matches(withText("newcity2")))
    }
    @Test
    fun editflinder(){
        val Iflinders = onView(withId(R.id.imgflinderstreet))
        Iflinders.perform(click())
        val textflider = onView(withId(R.id.title))
        textflider.perform(replaceText("newcity3"))
        pressBack()
        val checkfilders = onView(withId(R.id.tflinderstreet))
        checkfilders.check(ViewAssertions.matches(withText("newcity3")))
    }
    @Test
    fun editcapetown(){
        val Icaptown = onView(withId(R.id.imgcaptown))
        Icaptown.perform(click())
        val textcaptown = onView(withId(R.id.title))
        textcaptown.perform(replaceText("newcity4-"))
        pressBack()
        val checkcaptown = onView(withId(R.id.tcapetown))
        checkcaptown.check(ViewAssertions.matches(withText("newcity4-")))
    }

}