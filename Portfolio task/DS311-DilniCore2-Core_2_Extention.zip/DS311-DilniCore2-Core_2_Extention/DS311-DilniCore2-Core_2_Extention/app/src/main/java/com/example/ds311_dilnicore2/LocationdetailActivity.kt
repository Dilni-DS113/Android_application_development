package com.example.ds311_dilnicore2


import android.annotation.SuppressLint
import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.Toast


class LocationdetailActivity : AppCompatActivity() {

    var transfer:Transfer? = null

    @SuppressLint("UseCompatLoadingForDrawables")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_locationdetail)
        val transfer = intent.getParcelableExtra<Transfer>("data")

        transfer?.let {
            val image = findViewById<ImageView>(R.id.imageView)
            image.setImageDrawable(getDrawable(it.opimg))

          val title = findViewById<EditText>(R.id.title)
            title.setText( it.opTitle)
          val address = findViewById<EditText>(R.id.address)
            address.setText(it.opAddress)

            fun validatetextfeilds():Boolean{
                if(title.length() < 5 )
                {
                    val message1 = "Title is to short"
                    val duration1 = Toast.LENGTH_LONG
                    val toast1 = Toast.makeText(this , message1,duration1)
                    title.error = toast1.show().toString()
                    return false
                }
                else if (address.length() < 8)
                {
                    val message2 = "Address is to short"
                    val duration2 = Toast.LENGTH_LONG
                    val toast2 = Toast.makeText(this,message2,duration2)
                    address.error = toast2.show().toString()
                    return false
                }
                return true
            }
            validatetextfeilds()
            val date = findViewById<EditText>(R.id.date)
            date.setText(it.opDate)

            val rating = findViewById<RatingBar>(R.id.cityrating)
            rating.rating = it.opRating
        }
    }

    override fun onBackPressed(){
        transfer?.opRating = findViewById<RatingBar>(R.id.cityrating).rating
        transfer?.opTitle = findViewById<EditText>(R.id.title).text.toString()
        val i = intent.apply {
            putExtra("Changed",transfer)
        }
        setResult(Activity.RESULT_OK,i)
        super.onBackPressed()
    }
}