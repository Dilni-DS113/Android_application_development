package com.example.ds311_dilnicore2

import android.content.Intent
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {
    lateinit var louvredata:Transfer
    lateinit var shibuyadata:Transfer
    lateinit var flinderdata:Transfer
    lateinit var capetowndata:Transfer
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        setContentView(R.layout.activity_main)
        val imglouvre = findViewById<ImageView>(R.id.imglourve)
        val imgshibuya = findViewById<ImageView>(R.id.imgshibuya)
        val imgflinderstreet = findViewById<ImageView>(R.id.imgflinderstreet)
        val imgcaptown = findViewById<ImageView>(R.id.imgcaptown)

        val ratelourve = findViewById<TextView>(R.id.ratinglourve)
        val rateshibuya = findViewById<TextView>(R.id.ratingshibuya)
        val ratefliderstreet = findViewById<TextView>(R.id.ratingflinderstreet)
        val ratecapetown = findViewById<TextView>(R.id.ratingcapetown)

        val titlelouvre = findViewById<TextView>(R.id.tlourve)
        val titleshibuya = findViewById<TextView>(R.id.tshibuya)
        val titleflinderstreet = findViewById<TextView>(R.id.tflinderstreet)
        val titlecaptown = findViewById<TextView>(R.id.tcapetown)

        louvredata = Transfer(R.drawable.im1,titlelouvre.text.toString(),"Rue de Rivoli, 75001 Paris, France","21/09/2022",ratelourve.text.toString().toFloat())
        shibuyadata = Transfer(R.drawable.im2,titleshibuya.text.toString(),"2 Dogenzaka, Shibuya-ku, Tokyo, 150-0043","19/06/2022",rateshibuya.text.toString().toFloat())
        flinderdata = Transfer(R.drawable.im3,titleflinderstreet.text.toString(),"Flinders St, Melbourne VIC 3000","05/10/2021",ratefliderstreet.text.toString().toFloat())
        capetowndata = Transfer(R.drawable.im4,titlecaptown.text.toString(),"Civic Centre, 12 Hertzog Boulevard, Cape Town","01/07/2022",ratecapetown.text.toString().toFloat())
      imglouvre.setOnClickListener {
        val intent = Intent(this,LocationdetailActivity::class.java).apply {
              putExtra("data",louvredata)
        }
        // startActivity(intent)
          startForResult.launch(intent)
      }

      imgshibuya.setOnClickListener {
          val intent = Intent(this,LocationdetailActivity::class.java).apply {
              putExtra("data",shibuyadata)
          }
       // startActivity(intent)
          startForResult.launch(intent)
      }

      imgflinderstreet.setOnClickListener {
          val intent = Intent(this,LocationdetailActivity::class.java).apply {
              putExtra("data",flinderdata)
          }
       // startActivity(intent)
          startForResult.launch(intent)
      }

      imgcaptown.setOnClickListener {
          val intent = Intent(this,LocationdetailActivity::class.java).apply {
              putExtra("data",capetowndata)
          }
        // startActivity(intent)
          startForResult.launch(intent)
      }
    }

    val startForResult =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()){ result ->
            when(result.resultCode){
                RESULT_OK ->{
                    val data = result.data
                    val edited = data?.getParcelableExtra<Transfer>("Edited")
                    val lourevrating = findViewById<TextView>(R.id.ratinglourve)
                    val lourevtitle = findViewById<TextView>(R.id.tlourve)

                    val shibuyarating = findViewById<TextView>(R.id.ratingshibuya)
                    val shibuyatitle = findViewById<TextView>(R.id.tshibuya)

                    val flinderstreetrating = findViewById<TextView>(R.id.ratingflinderstreet)
                    val flinderstreettitle = findViewById<TextView>(R.id.tflinderstreet)

                    val captownrating = findViewById<TextView>(R.id.ratingcapetown)
                    val capetowntitle = findViewById<TextView>(R.id.tcapetown)
                    edited?.let {
                        louvredata = edited
                        shibuyadata = edited
                        flinderdata = edited
                        capetowndata = edited


                    }
                }
            }



        }




}