# DS311-DilniCore2
Assignment: Core 2 
The app for this assignment demonstrated the function of passing data between two activities.The data displayed is dependant of what image the user pressed.
Below show all fisrt 9 commits from the classroom respotory: 
- Fisrt - added empty project
- Second: homepage / start activity :)
- Second: editing image view by enabling importing images into drawable…
- third: fisrt attempt at tranfering data
- Fourth: Transfered Diffrent City tile from main Acitivity to location…
- Fourth: editing variable name
- Fourth: attempt 1 passing images between actvites
- Fourth: attempt 1 passing images between actvites edit
- fifth: 70% complete implementing paraciables
- Sixth: 75% finihsed paraciable from second acitivty to first activity
- seventh: failed attempt on trasfering data between activities
- Eighth: altering intent
- Nineth:parciable unable to function
- Nineth:parciable one object sent
