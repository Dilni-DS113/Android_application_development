package com.example.ds311_dilnicore2


import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView

class LocationdetailActivity : AppCompatActivity() {

    @SuppressLint("UseCompatLoadingForDrawables")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_locationdetail)
        val transfer = intent.getParcelableExtra<Transfer>("data")

        transfer?.let {
            val image = findViewById<ImageView>(R.id.imageView)
            image.setImageDrawable(getDrawable(it.opimg))

            val title = findViewById<TextView>(R.id.citytitle)
            title.text = it.opTitle

            val address = findViewById<TextView>(R.id.address)
            address.text = it.opAddress

            val date = findViewById<TextView>(R.id.date)
            date.text = it.opDate

            val rating = findViewById<RatingBar>(R.id.cityrating)
            rating.rating = it.opRating
        }
    }
}