package com.example.ds311_dilnicore2

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize

data class Transfer(var opimg:Int,var opTitle:String, var opAddress: String, var opDate:String ,var opRating:Float ):Parcelable
{}