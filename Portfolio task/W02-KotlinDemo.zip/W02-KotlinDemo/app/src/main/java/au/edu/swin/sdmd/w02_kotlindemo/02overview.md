# My second Kotlin program

This code contains some important concepts you'll need: again let's see if we can spot them all!

* defining classes and initialising them
* using loops

## To be implemented

* using scoping functions such as `with` and `apply`
* using data classes and copying
* custom accessors