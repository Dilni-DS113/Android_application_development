# Overview

## Week 2 -- Kotlin

This week should have seen the creation of Card and Program.kt.

## Week 3 -- Building blocks

This week should have seen the refactoring of activity_main.xml and MainActivity.

## Week 4 -- Unit testing

This week should have seen the refactoring of ExampleUnitTest.