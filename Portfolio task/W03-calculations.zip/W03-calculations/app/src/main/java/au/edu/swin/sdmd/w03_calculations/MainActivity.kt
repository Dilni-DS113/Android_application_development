package au.edu.swin.sdmd.w03_calculations

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView

class MainActivity : AppCompatActivity() {
   var opResult: Int = 0

    override fun onStart() {
        super.onStart()
        Log.i("LIFECYCLE","onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.i("LIFECYCLE","onResume")
    }

    // Shared Preferences is the way in which one can store and retrieve small amounts of primitive data
    // As key/value pairs to a file on the device storage
    override fun onPause() {
        super.onPause()
        Log.i("LIFECYCLE","onPause")

        val sharedPref = this.getSharedPreferences("myfile",Context.MODE_PRIVATE) ?:return
        with(sharedPref.edit()){
            val number1 = findViewById<EditText>(R.id.number1)
            putString("num1",number1.text.toString()) // saving the number 1 int value
            val number2 = findViewById<EditText>(R.id.number2)
            putString("num2",number2.text.toString()) // saving the number 2 int value
            val answer = findViewById<TextView>(R.id.answer)// saving result value
            putString("ans",answer.text.toString())
            apply()
        }
    }

    override fun onStop() {
        super.onStop()
        Log.i("LIFECYCLE","onStop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i("LIFECYCLE","onDestroy")
    }

    override fun onRestart() {
        super.onRestart()
        Log.i("LIFECYCLE","onRestart")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.i("LIFECYCLE","onCreate")

        val number1 = findViewById<EditText>(R.id.number1)
        val number2 = findViewById<EditText>(R.id.number2)

        val plus = findViewById<RadioButton>(R.id.plus)
        val multiply = findViewById<RadioButton>(R.id.multiply)

        val answer = findViewById<TextView>(R.id.answer)
        val equals = findViewById<Button>(R.id.equals)

        val sharedPref = this.getSharedPreferences("myfile",Context.MODE_PRIVATE)
        val num1 = sharedPref.getString("num1","0").toString()
        val num2 = sharedPref.getString("num2","0").toString()
        val ans = sharedPref.getString("ans","0").toString()

        number1.setText(num1)
        number2.setText(num2)
        answer.setText(ans)


     /*   savedInstanceState?.let {
            opResult = savedInstanceState.getInt("answer")
            answer.text = opResult.toString()
        }*/

         plus.setOnClickListener {
          equals.setOnClickListener {
             opResult = add(number1.text.toString(), number2.text.toString())
            // TODO: show result on the screen
            answer.text = opResult.toString()

          }
        }

        multiply.setOnClickListener {
            equals.setOnClickListener {
                opResult = product(number1.text.toString(), number2.text.toString())
                answer.text = opResult.toString()
            }
        }
    }

  /*  override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("answer", opResult)
        Log.i("LIFECYCLE", "saveInstanceState $opResult")
    }*/

    // adds two numbers together
    private fun add(number1: String, number2: String) = number1.toInt() + number2.toInt()
    // multiply two number together
    private fun product(number1: String,number2: String) = number1.toInt() * number2.toInt()
}