package com.example.w6timetableapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat.startActivity
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvFactor1 = findViewById<TextInputEditText>(R.id.factor1)
        val tvfactorLayout1 = findViewById<TextInputLayout>(R.id.tilfactor1)
        val tvfactorLayout2 = findViewById<TextInputLayout>(R.id.tilfactor2)
        val tvFactor2 = findViewById<TextInputEditText>(R.id.factor2)

        val multiply = findViewById<Button>(R.id.multiply)
        multiply.setOnClickListener {
            val factor1 = tvFactor1.text.toString().toInt()
            val factor2 = tvFactor2.text.toString().toInt()
            if ((factor1 in 1..12) && (factor2 in 1..12)){
                val intent = Intent(this,ResultActivity::class.java).apply {
                    putExtra("Result", Result(factor1*factor2))
                }
                startActivity(intent)
            }else {
                tvfactorLayout1.error = "value must be between 1 - 13"
                tvfactorLayout2.error = "value must be between 1 - 13"
            }

        }
    }
}