package com.example.w6timetableapp

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize
import kotlin.Result

@Parcelize
data class Result(val opResult: Int):Parcelable {
}