package com.example.w6timetableapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView



class ResultActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        val result = intent.getParcelableExtra<Result>("Result")
        val tvResult = findViewById<TextView>(R.id.Result)
        tvResult.text = result?.opResult.toString()



    }
}